class Contabilidade:
    def __init__(self):
        self.transacoes = []
        self.funcionarios = []
